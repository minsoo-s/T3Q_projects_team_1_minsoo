# 파일명: image_classification_train_sub.py

# Imports
import cv2
import os, glob, yaml, zipfile, cv2
from sklearn.model_selection import train_test_split
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import utils
from tensorflow.keras import layers
from tensorflow.keras.models import load_model

import logging
import base64
import io
from PIL import Image
from pylabel import importer
from glob import glob
from pprint import pprint
#from meta_data.dataset.model.yolov5.detect import run

import matplotlib.pyplot as plt
import matplotlib.image as img
import matplotlib.colors as mcolors

logging.info(f'[hunmin log] tensorflow ver : {tf.__version__}')

gpus = tf.config.experimental.list_physical_devices('GPU')
if gpus:
    try:
        tf.config.experimental.set_visible_devices(gpus, 'GPU')
        logging.info('[hunmin log] gpu set complete')
        logging.info('[hunmin log] num of gpu: {}'.format(len(gpus)))

    except RuntimeError as e:
        logging.info('[hunmin log] gpu set failed')
        logging.info(e)


def exec_train(tm):
    logging.info('[hunmin log] the start line of the function [exec_train]')

    logging.info('[hunmin log] tm.train_data_path : {}'.format(tm.train_data_path))

    # 저장 파일 확인
    list_files_directories(tm.train_data_path)

    ###########################################################################
    ## 1. 데이터셋 준비(Data Setup)
    ###########################################################################

    # 이미지, 라벨 데이터 확인-----------------------------
    img_path = os.path.join(tm.train_data_path, 'dataset/dataset/images/')
    label_path = os.path.join(tm.train_data_path, 'dataset/dataset/labels/')
    annotation_path = os.path.join(tm.train_data_path, 'dataset/dataset/Annotations/')

    img_list = os.listdir(img_path)
    label_list = os.listdir(label_path)
    annotation_list = os.listdir(annotation_path)

    img_count = len(img_list)
    label_count = len(label_list)
    annotation_count = len(annotation_list)
    logging.info('[hunmin log] 1. Data Setup start ------------------')
    logging.info('[hunmin log] Image data count: {}'.format(img_count))
    logging.info('[hunmin log] Label data count: {}'.format(label_count))
    logging.info('[hunmin log] Annotation data count: {}'.format(annotation_count))

    # 이미지 사이즈 확인---------------------------------
    from PIL import Image
    import matplotlib.pyplot as plt

    image1 = Image.open(img_path + img_list[1000])
    imag1_size = image1.size
    logging.info('[hunmin log] image_size_width : {}'.format(imag1_size[0]))
    logging.info('[hunmin log] image_size_height : {}'.format(imag1_size[1]))

    ###########################################################################
    ## 2. 데이터 전처리(Data Preprocessing)
    ###########################################################################

    ### annotation 폴더 내의 json 파일 불러오기
    LABEL_PATH = os.path.join(tm.train_data_path, 'dataset/dataset/Annotations/')
    LABEL_SAVE_PATH = os.path.join(tm.train_data_path, 'dataset/dataset/labels/')
    json_list = os.listdir(LABEL_PATH)

    ### json -> txt / COCO -> YOLO 포맷 변경
    for file in json_list:
        dataset = importer.ImportCoco(LABEL_PATH + file)

        # 좌표 변경을 위한 변수 지정
        bbox_x = int(dataset.df.iloc[0].ann_bbox_xmin)
        bbox_y = int(dataset.df.iloc[0].ann_bbox_ymin)
        height = int(dataset.df.iloc[0].ann_bbox_height)
        width = int(dataset.df.iloc[0].ann_bbox_width)
        img_height = int(dataset.df.iloc[0].img_height)
        img_width = int(dataset.df.iloc[0].img_width)

        # 카테고리 id, 해당하는 이미지의 이름 정보
        img_category = int(dataset.df.iloc[0].cat_id)
        img_name = dataset.df.iloc[0].img_filename[:-3]

        # 카테고리 id가 0~6안에 있어야하기 때문에 카테고리 id 재설정
        if img_category == 2:
            img_category = img_category - 1
        elif img_category == 3:
            img_category = img_category - 1
        elif img_category == 4:
            img_category = img_category - 1
        elif img_category == 5:
            img_category = img_category - 1
        elif img_category == 9:
            img_category = img_category - 4
        elif img_category == 10:
            img_category = img_category - 4

        # img_height, img_width 정보 누락 방지
        if img_height != 720:
            img_height = 720
        if img_width != 1280:
            img_width = 1280

        # COCO -> YOLO 포맷으로 바운딩 박스 좌표 기준 변경
        dw = 1.0 / img_width
        dh = 1.0 / img_height
        x_center = bbox_x + width / 2.0
        y_center = bbox_y + height / 2.0
        x = x_center * dw
        y = y_center * dh
        w = width * dw
        h = height * dh

        # SAVE_PATH가 없으면 생성
        if not os.path.exists(LABEL_SAVE_PATH):
            os.makedirs(LABEL_SAVE_PATH)

        # txt파일이 없으면 생성
        if not os.path.isfile(LABEL_SAVE_PATH + '/' + img_name + 'txt'):
            f = open(LABEL_SAVE_PATH + '/' + img_name + 'txt', 'w')
            f.close()

        # 변경된 좌표값, 카테고리 id를 이용해 txt포맷의 라벨링 데이터 생성
        f = open(LABEL_SAVE_PATH + '/' + img_name + 'txt', 'a')
        f.write(str(img_category) + ' ')
        f.write(str(x) + ' ')
        f.write(str(y) + ' ')
        f.write(str(w) + ' ')
        f.write(str(h) + '\n')
        f.close()

    total_label_count = len(os.listdir(LABEL_SAVE_PATH))

    logging.info('[hunmin log] 2. Data_preprocessing start ----------------------')
    logging.info('[hunmin log] 2-1. labeling data type change')
    logging.info('[hunmin log] total label data count : {}'.format(total_label_count))

    ### 데이터 시각화 ----------------------------------------------------------
    # 학습 카테고리 분포 확인
    cat_name = ["Pothole on road",
                "Person",
                "Garbage bag & sacks",
                "Construction signs",
                "Traffic cone",
                "Filled pothole",
                "Manhole"]
    LABEL_SAVE_PATH = os.path.join(tm.train_data_path, 'dataset/dataset/labels/')
    label_list = os.listdir(LABEL_SAVE_PATH)

    # 라벨 정보를 불러와서 카테고리 id부분만 읽어서 리스트에 저장
    cat_list = []
    for label in label_list:
        f = open(LABEL_SAVE_PATH + '/' + label, 'r')
        cat_list.append(int(f.readline()[:2]))
        f.close()

    # 카테고리 빈도수 확인
    cat_count = []
    for i in range(0, 7):
        cat_count.append(cat_list.count(i))

    # 타입, 라벨링 방식 통일된 데이터의 분포 및 개수 확인
    logging.info('[hunmin log] 2-2. category info')
    logging.info('[hunmin log] category names: {}'.format(cat_name))
    logging.info('[hunmin log] category count: {}'.format(cat_count))

    ### 이미지 파일 리스트 생성 ------------------------
    DIR_LIST = os.path.abspath(f'{tm.train_data_path}/dataset/dataset/images')
    DIR_PATH = os.path.abspath(f'{tm.train_data_path}/dataset/dataset/')

    train_img_list = glob(f'{DIR_LIST}/*.png')

    ### 훈련 & 평가 데이터셋 생성----------------------------
    train_img_list, val_img_list = train_test_split(train_img_list,
                                                    train_size=0.9,
                                                    random_state=42)
    train_count = len(train_img_list)
    val_count = len(val_img_list)
    logging.info('[hunmin log] 2-3.train_Validation split')
    logging.info('[hunmin log] Train Image count: {}'.format(train_count))
    logging.info('[hunmin log] Validation Image count: {}'.format(val_count))

    ### 학습, 테스트 데이터셋의 정보를 담은 txt파일 생성 -----
    # train/val 이미지 경로 txt파일로 저장
    with open(f'{DIR_PATH}/train.txt', 'w') as f:
        f.write('\n'.join(train_img_list) + '\n')

    with open(f'{DIR_PATH}/val.txt', 'w') as f:
        f.write('\n'.join(val_img_list) + '\n')

    logging.info('[hunmin log] 2-4. write iamge path to txt type')

    ### Yaml 파일 최신화  ----------------------------------
    # yaml 생성
    with open(f'{DIR_PATH}/data.yaml', 'r') as f:
        data = yaml.full_load(f)

    data['train'] = f'{DIR_PATH}/train.txt'
    data['val'] = f'{DIR_PATH}/val.txt'

    with open(f'{DIR_PATH}/data.yaml', 'w') as f:
        yaml.dump(data, f)

    logging.info('[hunmin log] 2-5. create data.yaml ')
    logging.info('[hunmin log] data.yaml info: {}'.format(data))

    ###########################################################################
    ## 3. 모델 학습(Train Model)
    ###########################################################################
    logging.info('[hunmin log]: 3.Model Train start ---------------------------')
    # 객체 인식을 위해 yolov5를 이용하려 한다.
    # 모델 학습(train.py)
    # --batch : batch size
    # --epochs : 학습 횟수
    # --data : data.yaml 경로
    # --cfg : yolov5 모델 구조
    # --weights : yolov5 모델 가중치
    # --project : 학습된 모델이 저장될 project의 경로
    # --device : gpu 사용번호 
    # --name: 저장폴더명
    # CUDA_VISIBLE_DEVICES = 0  device == 0 
    terminal_command = "python3 ./meta_data/dataset/model/yolov5/train.py --batch 16 --epochs 2 --workers 0 --data ./meta_data/dataset/dataset/data.yaml --cfg ./meta_data/dataset/model/yolov5/models/yolov5s.yaml --weights ./meta_data/dataset/model/yolov5/yolov5s.pt --name train_results"
    os.system(terminal_command)

    # 학습 결과 저장 확인
    TRAIN_RESULT_PATH = os.path.join(tm.train_data_path, 'dataset/model/yolov5/runs/train/train_results/')
    list_files_directories(TRAIN_RESULT_PATH)
    logging.info('[hunmin log]: 3-1. yolov5 model train completed')

    logging.info('[hunmin log]: 3-2. Evaluate Model')
    ##########################################################################
    # 플랫폼 시각화
    ##########################################################################

    #     # 모델 평가(Evaluate Model)
    #     address_matrix = os.path.join(tm.model_path,'train_results/confusion_matrix.png')
    #     address_graph = os.path.join(tm.model_path,'train_results/results.png')
    #     address_label = os.path.join(tm.model_path,'train_results/val_batch0_labels.png')
    #     address_pred = os.path.join(tm.model_path,'train_results/val_batch0_pred.png')

    #     # # 이미지, 라벨 시각화
    #     matrix = img.imread(address_matrix)
    #     graph = img.imread(address_graph)
    #     label = img.imread(address_label)
    #     pred = img.imread(address_pred)

    #     # 혼동행렬
    #     plt.figure(figsize=(16,12))
    #     plt.subplot(2, 2, 1)
    #     plt.title('confusion metirix')
    #     plt.imshow(matrix)

    #     # box_loss, object_loss, class_loss, presicion, recall, mAP_0.5, mAP_0.5:0.95
    #     plt.subplot(2, 2, 2)
    #     plt.title('graph')
    #     plt.imshow(graph)

    #     # 학습할 때 사용한 라벨링 데이터
    #     plt.subplot(2, 2, 3)
    #     plt.title('label')
    #     plt.imshow(label)

    #     # 학습모델이 예측한 데이터
    #     plt.subplot(2, 2, 4)
    #     plt.title('predict')
    #     plt.imshow(pred)

    #     plt.axis('off')
    #     plt.show()

    ###########################################################################
    ## 학습 모델 저장
    ###########################################################################

    # 저장 파일 확인
    weight = os.path.join(tm.train_data_path, 'dataset/model/yolov5/runs/train/train_results/weights/best.pt')
    logging.info('[hunmin log]: 3-3. the finish line of the function [exec_train]')


def exec_init_svc(im):
    logging.info('[hunmin log] im.model_path : {}'.format(im.model_path))

    # 저장 파일 확인
    list_files_directories(im.model_path)

    ###########################################################################
    ## 학습 모델 준비
    ###########################################################################

    # load the model
    model = os.path.join(im.model_path, 'dataset/model/yolov5/runs/train/train_results/weights/best.pt')

    return model


def exec_inference(params):
    ###########################################################################
    ## 4. 추론(Inference)
    ###########################################################################

    logging.info('[hunmin log] the start line of the function [exec_inference]')

    # 테스트할 이미지 또는 영상 source 경로 설정
    # source = os.path.join(tm.train_data_path,
    #                         'dataset/test_dataset/V0F_HY_1505_20201227_101811_N_CH2_Busan_Sun_Mainroad_Day_51810.png')
    # result_save_path = os.path.join(tm.train_data_path, 'detect_result/exp/')

    terminal_command = "python3 ./meta_data/dataset/model/yolov5/detect.py --weights ./meta_data/model/yolov5/runs/train/train_results/weights/best.pt --img 416 --conf 0.3 --source dataset/test_dataset/V0F_HY_1505_20201227_101811_N_CH2_Busan_Sun_Mainroad_Day_51810.png"
    os.system(terminal_command)
    # run(weights=params,
    #     source=source,
    #     conf_thres=0.3,
    #     line_thickness=2,
    #     project=result_save_path)
    save_result = os.path.join(im.model_path,'detect_result/detected_image.png')

    result = {'inference' : save_result }
    return result


# 저장 파일 확인
def list_files_directories(path):
    # Get the list of all files and directories in current working directory
    dir_list = os.listdir(path)
    logging.info('[hunmin log] Files and directories in {} :'.format(path))
    logging.info('[hunmin log] dir_list : {}'.format(dir_list))